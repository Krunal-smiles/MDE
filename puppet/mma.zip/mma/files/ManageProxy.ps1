﻿[CmdletBinding()]
param([Parameter(Mandatory=$True,Position=1)][string]$action,
      [Parameter(Mandatory=$False,Position=2)][string]$proxyserver,
      [Parameter(Mandatory=$False)][string]$proxyuname,
      [Parameter(Mandatory=$False)][string]$proxypwd
)

try {
  $mma = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
  $proxy=$mma.proxyUrl
} catch {
  Write-Output "Failed to get proxy object"
  exit 2
}

switch ($action) {
  "check" {
    if ($proxyserver -and $proxyuname) {
      if (($proxy -eq $proxyserver) -and ($proxyuname -eq $mma.proxyUsername)) { exit 0 } else { exit 1 }
    } elseif ($proxyserver) {
      if (($proxy -eq $proxyserver) -and ($mma.proxyUsername -eq '')) { exit 0 } else { exit 1 }
    } else {
      if (($proxy -eq '') -or ($null -eq $proxy)) { exit 0 } else { exit 1 }
    }
  }

  "set" {
    if ($proxyserver) {
      $mma.SetProxyInfo($proxyserver, $proxyuname, $proxypwd)
    } else {
      $mma.SetProxyInfo('', '', '')
    }
    exit 0
  }

  "reset" {
    $mma.SetProxyInfo('', '', '')
    exit 0
  }

  default {
    Write-Output "Unknown supported action, use check/set/reset"
    exit 2
  }
}
