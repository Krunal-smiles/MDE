﻿[CmdletBinding()]
param([Parameter(Mandatory=$True,Position=1)][string]$action,
      [Parameter(Mandatory=$True,Position=2)][string]$workspaceid,
      [Parameter(Mandatory=$False)][string]$workspacekey
)

try {
  $mma = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
  $workspace = $mma.GetCloudWorkspace($workspaceid)
} catch {
  Write-Output "Failed to get workspace object"
  exit 2
}

switch ($action) {
  "checkset" {
    if ($null -ne $workspace) { exit 0 } else { exit 1 }
  }

  "checkunset" {
    if ($null -eq $workspace) { exit 0 } else { exit 1 }
  }

  "add" {
    if ($null -eq $workspace) {
      if (($workspaceid -eq '') -or ($null -eq $workspaceid) -or ($workspacekey -eq '') -or ($null -eq $workspacekey)) {
        Write-Output "Workspace Id and Workspace key is required"
        exit 1
      }
      $mma.AddCloudWorkspace($workspaceid,$workspacekey)
      $mma.ReloadConfiguration()
    }
    exit 0
  }

  "remove" {
    if ($null -ne $workspace) {
      $mma.RemoveCloudWorkspace($workspaceid)
      $mma.ReloadConfiguration()
    }
    exit 0
  }

  default {
    Write-Output "Unknown supported action, use checkset/checkunset/add/remove"
    exit 2
  }
}
